import turtle

window = turtle.Screen()
window.setup(500, 500)
my_ttl = turtle.Turtle()

######################################################
## Go Crazy and make something amazing with loops!! ##
######################################################

for side in range(1,5):
    my_ttl.forward(20)
    my_ttl.left(90)
    my_ttl.forward(20)
    my_ttl.left(90)
    my_ttl.forward(20)
    my_ttl.left(90)
    my_ttl.forward(20)
