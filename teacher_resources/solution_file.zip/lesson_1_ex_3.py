## Draw a hexagon with the Turtle ##

import turtle

window = turtle.Screen()
window.setup(500, 500)

my_ttl = turtle.Turtle()

## Write your code below this line ##
my_ttl.forward(100)
my_ttl.left(60)
my_ttl.forward(100)
my_ttl.left(60)
my_ttl.forward(100)
my_ttl.left(60)
my_ttl.forward(100)
my_ttl.left(60)
my_ttl.forward(100)
my_ttl.left(60)
my_ttl.forward(100)
my_ttl.left(60)