import turtle

# set up screen
screen = 500
window = turtle.Screen()
window.setup(screen, screen)

# create turtle instance
my_ttl = turtle.Turtle()
my_ttl.shape("arrow")

###################################
## Using the turtle commands you ##
## have learnt, draw a house.    ##
###################################