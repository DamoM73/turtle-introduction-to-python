###############################################
## write a program that askes the user for a ##
## number and then counts up to that number. ##
###############################################