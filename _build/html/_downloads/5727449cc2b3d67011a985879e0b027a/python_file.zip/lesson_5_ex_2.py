# Almy_ttl's security guard program

friends = "Bruce"

######################################################
## Write a program that asks for a person's name    ##
## and then grants entry of that person is Almy_ttl ##
## or a friend of Almy_ttl.                         ##
## Everyone else is told, politely, to go away      ##
######################################################