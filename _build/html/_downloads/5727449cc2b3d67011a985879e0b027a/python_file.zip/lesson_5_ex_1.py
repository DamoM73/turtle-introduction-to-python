# Almy_ttl's security guard program

######################################################
## Write a program that asks for a person's name    ##
## and then grants entry of that person is Almy_ttl ##
## everyone else is told, politely, to go away      ##
######################################################